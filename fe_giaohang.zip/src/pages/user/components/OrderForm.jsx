import React, { useMemo, useRef, useState, useEffect, useCallback } from "react";
import { EnvironmentOutlined, AimOutlined, SearchOutlined, DollarOutlined } from "@ant-design/icons";
import { Form, Input, Button, Card, Row, Col, Segmented, Space, Radio, message } from "antd";
// OpenStreetMap via react-leaflet
import { MapContainer, TileLayer, Marker, useMapEvents } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import { calculateRoadDistance } from "../../../utils/distance";

const { TextArea } = Input;

const OrderForm = ({
   form,
   onSubmit,
   submitting,
   totalPrice,
   formatCurrency,
   onDistanceChange // Callback để truyền khoảng cách về component cha
}) => {
   // icon marker tuỳ biến nhỏ gọn
   const markerIcon = useMemo(() => new L.Icon({
      iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
      iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
      shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
      iconSize: [25, 41],
      iconAnchor: [12, 41],
      popupAnchor: [1, -34],
      shadowSize: [41, 41]
   }), []);

   const [activePoint, setActivePoint] = useState("pickup"); // pickup | dropoff
   const [searchQuery, setSearchQuery] = useState("");
   const [calculatingDistance, setCalculatingDistance] = useState(false);
   const debounceTimerRef = useRef(null);

   const defaultCenter = useMemo(() => ({ lat: 16.047079, lng: 108.206230 }), []); // Đà Nẵng

   // Sử dụng Form.useWatch để theo dõi thay đổi tọa độ
   const pickupLat = Form.useWatch("pickupLat", form);
   const pickupLng = Form.useWatch("pickupLng", form);
   const dropoffLat = Form.useWatch("dropoffLat", form);
   const dropoffLng = Form.useWatch("dropoffLng", form);

   const getPoint = (key) => {
      const lat = form.getFieldValue(`${key}Lat`);
      const lng = form.getFieldValue(`${key}Lng`);
      if (typeof lat === "number" && typeof lng === "number") return { lat, lng };
      return null;
   };

   const setPoint = (key, lat, lng) => {
      form.setFieldsValue({ [`${key}Lat`]: lat, [`${key}Lng`]: lng });
   };

   // Tính khoảng cách khi có đủ cả hai điểm
   const calculateDistance = useCallback(async () => {
      const pickup = getPoint("pickup");
      const dropoff = getPoint("dropoff");

      if (!pickup || !dropoff) {
         if (onDistanceChange) {
            onDistanceChange(null);
         }
         return;
      }

      setCalculatingDistance(true);
      try {
         const distance = await calculateRoadDistance(
            pickup.lat,
            pickup.lng,
            dropoff.lat,
            dropoff.lng
         );
         
         if (distance > 0 && onDistanceChange) {
            onDistanceChange(distance);
         }
      } catch (error) {
         console.error("Lỗi khi tính khoảng cách:", error);
         message.error("Không thể tính khoảng cách. Vui lòng thử lại.");
      } finally {
         setCalculatingDistance(false);
      }
   }, [onDistanceChange, form]);

   // Theo dõi thay đổi tọa độ và tự động tính khoảng cách
   useEffect(() => {
      // Clear timer trước đó nếu có
      if (debounceTimerRef.current) {
         clearTimeout(debounceTimerRef.current);
      }

      // Kiểm tra nếu có đủ cả hai điểm
      if (pickupLat && pickupLng && dropoffLat && dropoffLng) {
         // Debounce để tránh tính toán quá nhiều lần
         debounceTimerRef.current = setTimeout(() => {
            calculateDistance();
         }, 500);
      } else {
         // Nếu thiếu điểm, đặt khoảng cách về null
         if (onDistanceChange) {
            onDistanceChange(null);
         }
      }

      return () => {
         if (debounceTimerRef.current) {
            clearTimeout(debounceTimerRef.current);
         }
      };
   }, [pickupLat, pickupLng, dropoffLat, dropoffLng, calculateDistance, onDistanceChange]);

   // Cleanup timers khi component unmount
   useEffect(() => {
      return () => {
         if (debounceTimerRef.current) {
            clearTimeout(debounceTimerRef.current);
         }
         if (addressGeocodeTimerRef.current.pickup) {
            clearTimeout(addressGeocodeTimerRef.current.pickup);
         }
         if (addressGeocodeTimerRef.current.dropoff) {
            clearTimeout(addressGeocodeTimerRef.current.dropoff);
         }
      };
   }, []);

   const reverseGeocode = async (lat, lng) => {
      try {
         const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&addressdetails=1&zoom=18`;
         const resp = await fetch(url, { headers: { "Accept": "application/json" } });
         const data = await resp.json();
         return data?.display_name || "";
      } catch {
         return "";
      }
   };

   const geocode = async (query) => {
      if (!query) return null;
      const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&countrycodes=vn&limit=1`;
      const resp = await fetch(url, { headers: { "Accept": "application/json" } });
      const results = await resp.json();
      if (Array.isArray(results) && results[0]) {
         const r = results[0];
         return { lat: parseFloat(r.lat), lng: parseFloat(r.lon), label: r.display_name };
      }
      return null;
   };

   const MapClick = ({ currentKey }) => {
      useMapEvents({
         async click(e) {
            const { lat, lng } = e.latlng;
            setPoint(currentKey, lat, lng);
            const addr = await reverseGeocode(lat, lng);
            if (addr) {
               const field = currentKey === "pickup" ? "pickupAddress" : "dropoffAddress";
               form.setFieldsValue({ [field]: addr });
            }
         }
      });
      return null;
   };

   const handleSearch = async () => {
      const res = await geocode(searchQuery);
      if (!res) return;
      setPoint(activePoint, res.lat, res.lng);
      const field = activePoint === "pickup" ? "pickupAddress" : "dropoffAddress";
      if (res.label) form.setFieldsValue({ [field]: res.label });
   };

   // Geocode địa chỉ khi người dùng nhập thủ công
   const handleAddressGeocode = async (address, fieldType) => {
      if (!address || address.trim().length < 5) return; // Chỉ geocode nếu địa chỉ đủ dài

      try {
         const res = await geocode(address);
         if (res) {
            setPoint(fieldType, res.lat, res.lng);
            // Cập nhật lại địa chỉ với format từ geocoding nếu cần
            if (res.label && res.label !== address) {
               form.setFieldsValue({ [fieldType === "pickup" ? "pickupAddress" : "dropoffAddress"]: res.label });
            }
         }
      } catch (error) {
         console.error("Lỗi khi geocode địa chỉ:", error);
      }
   };

   // Debounce cho việc geocode địa chỉ khi người dùng nhập
   const addressGeocodeTimerRef = useRef({ pickup: null, dropoff: null });

   const handleAddressChange = (fieldType, address) => {
      // Clear timer trước đó
      if (addressGeocodeTimerRef.current[fieldType]) {
         clearTimeout(addressGeocodeTimerRef.current[fieldType]);
      }

      // Đợi 1.5 giây sau khi người dùng ngừng nhập rồi mới geocode
      addressGeocodeTimerRef.current[fieldType] = setTimeout(() => {
         handleAddressGeocode(address, fieldType);
      }, 1500);
   };

   return (
      <Card title="Thông tin đơn hàng" className="shadow-sm">
         <Form
            form={form}
            layout="vertical"
            onFinish={onSubmit}
            initialValues={{
               pickupAddress: "",
               dropoffAddress: "",
               customerNote: "",
               paymentBy: "sender" // Mặc định: người đặt trả tiền
            }}
         >
            {/* Khu vực địa điểm + Map */}
            <Row gutter={[16, 16]}>
               <Col xs={24} md={12}>
                  <Form.Item
                     name="pickupAddress"
                     label="Địa chỉ lấy hàng"
                     rules={[{ required: true, message: "Vui lòng nhập địa chỉ lấy hàng" }]}
                  >
                     <Input
                        prefix={<EnvironmentOutlined />}
                        placeholder="Nhập hoặc chọn trên bản đồ"
                        onBlur={(e) => {
                           const address = e.target.value;
                           if (address) {
                              handleAddressGeocode(address, "pickup");
                           }
                        }}
                        onChange={(e) => {
                           const address = e.target.value;
                           handleAddressChange("pickup", address);
                        }}
                     />
                  </Form.Item>
                  <Form.Item
                     name="dropoffAddress"
                     label="Địa chỉ giao hàng"
                     rules={[{ required: true, message: "Vui lòng nhập địa chỉ giao hàng" }]}
                  >
                     <Input
                        prefix={<EnvironmentOutlined />}
                        placeholder="Nhập hoặc chọn trên bản đồ"
                        onBlur={(e) => {
                           const address = e.target.value;
                           if (address) {
                              handleAddressGeocode(address, "dropoff");
                           }
                        }}
                        onChange={(e) => {
                           const address = e.target.value;
                           handleAddressChange("dropoff", address);
                        }}
                     />
                  </Form.Item>

                  {/* Hidden to store coords */}
                  <Form.Item name="pickupLat" hidden><Input /></Form.Item>
                  <Form.Item name="pickupLng" hidden><Input /></Form.Item>
                  <Form.Item name="dropoffLat" hidden><Input /></Form.Item>
                  <Form.Item name="dropoffLng" hidden><Input /></Form.Item>
               </Col>

               <Col xs={24} md={12}>
                  <div className="mb-2 flex items-center justify-between">
                     <Segmented
                        size="small"
                        value={activePoint}
                        onChange={setActivePoint}
                        options={[
                           { label: "Chọn điểm lấy", value: "pickup" },
                           { label: "Chọn điểm giao", value: "dropoff" }
                        ]}
                     />
                     <Space.Compact style={{ width: 260 }}>
                        <Input
                           allowClear
                           placeholder="Tìm địa điểm (OpenStreetMap)"
                           value={searchQuery}
                           onChange={(e) => setSearchQuery(e.target.value)}
                           prefix={<SearchOutlined />}
                        />
                        <Button onClick={handleSearch} icon={<AimOutlined />}>Chọn</Button>
                     </Space.Compact>
                  </div>
                  <div style={{ height: 280, borderRadius: 8, overflow: "hidden" }}>
                     <MapContainer
                        center={getPoint(activePoint) || defaultCenter}
                        zoom={13}
                        scrollWheelZoom
                        style={{ height: "100%", width: "100%" }}
                     >
                        <TileLayer
                           attribution='&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors'
                           url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                        />
                        {getPoint("pickup") && (
                           <Marker position={getPoint("pickup")} icon={markerIcon} />
                        )}
                        {getPoint("dropoff") && (
                           <Marker position={getPoint("dropoff")} icon={markerIcon} />
                        )}
                        <MapClick currentKey={activePoint} />
                     </MapContainer>
                  </div>
               </Col>
            </Row>

            {/* Payment By - Người trả tiền */}
            <Form.Item
               name="paymentBy"
               label={
                  <span>
                     <DollarOutlined className="mr-2" />
                     Người trả tiền
                  </span>
               }
               rules={[{ required: true, message: "Vui lòng chọn người trả tiền" }]}
            >
               <Radio.Group>
                  <Radio value="sender">
                     <div>
                        <strong>Người đặt trả tiền</strong>
                        <div className="text-xs text-gray-500 mt-1">
                           Thanh toán trước khi lấy hàng thành công
                        </div>
                     </div>
                  </Radio>
                  <Radio value="receiver" className="mt-2">
                     <div>
                        <strong>Người nhận trả tiền</strong>
                        <div className="text-xs text-gray-500 mt-1">
                           Thanh toán trước khi giao hàng thành công
                        </div>
                     </div>
                  </Radio>
               </Radio.Group>
            </Form.Item>

            {/* Customer Note */}
            <Form.Item
               name="customerNote"
               label="Ghi chú"
            >
               <TextArea
                  rows={2}
                  placeholder="Nhập ghi chú cho đơn hàng (nếu có)"
               />
            </Form.Item>

            {/* Submit Button */}
            <div className="flex justify-between items-center mt-2">
               <div className="text-lg">
                  <span className="font-medium">Tổng cộng: </span>
                  <span className="font-bold text-blue-600">
                     {formatCurrency(totalPrice)}
                  </span>
               </div>

               <Button
                  type="primary"
                  htmlType="submit"
                  loading={submitting}
                  className="bg-blue-600"
                  size="large"
               >
                  Đặt đơn hàng
               </Button>
            </div>
         </Form>
      </Card>
   );
};

export default OrderForm;
